### Name: bslnoff
### Title: Baseline Substraction
### Aliases: bslnoff
### Keywords: nonparametric

### ** Examples

fdat <- system.file("Test", package = "PROcess")
fs <- list.files(fdat, pattern="\.*csv\.*", full.names=TRUE)
f1 <- read.files(fs[1])
fcut <- f1[f1[,1]>0,]
bseoff <-bslnoff(fcut,method="loess",plot=TRUE, bw=0.1)
title(basename(fs[1]))



