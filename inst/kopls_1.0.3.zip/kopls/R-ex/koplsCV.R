### Name: koplsCV
### Title: K-OPLS cross-validation
### Aliases: koplsCV
### Keywords: multivariate

### ** Examples


## Load data set
data(koplsExample)

## Define kernel function parameter
sigma<-25 

## Construct kernel
Ktr<-koplsKernel(Xtr,NULL,'g',sigma)

## Find optimal number of Y-orthogonal components by cross-validation
## The cross-validation tests models with Y-orthogonal components 0 through numYo
modelCV<-koplsCV(Ktr,Ytr,1,3,nrcv=7,cvType='nfold',preProcK='mc',preProcY='mc',modelType='da')

## Visualize results
koplsPlotCVDiagnostics(modelCV)
title("Statistics from K-OPLS cross-validation of original data")




