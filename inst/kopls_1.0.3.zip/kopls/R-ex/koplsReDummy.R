### Name: koplsReDummy
### Title: Reconstruct class vector
### Aliases: koplsReDummy
### Keywords: multivariate

### ** Examples




