### Name: is.multiple
### Title: Find multiple-charged polypeptides.
### Aliases: is.multiple
### Keywords: arith

### ** Examples

bmks <- c(2360.25, 2666.34, 3055.72, 3058.04, 
3776.94, 3778.24, 3779.53, 4712.37,7559.76, 4587.03, 
4589.88, 9155.59, 13298.7)
is.multiple(bmks, k=2:5)



