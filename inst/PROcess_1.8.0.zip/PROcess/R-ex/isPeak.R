### Name: isPeak
### Title: Locate Peaks in a Spectrum
### Aliases: isPeak
### Keywords: nonparametric

### ** Examples

example(bslnoff)
pkobj <- isPeak(bseoff,span=81,sm.span=11,plot=TRUE)




