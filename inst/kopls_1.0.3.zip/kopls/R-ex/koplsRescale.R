### Name: koplsRescale
### Title: Matrix scaling based on pre-defined parameters
### Aliases: koplsRescale
### Keywords: multivariate

### ** Examples




