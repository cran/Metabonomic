### Name: getPeaks
### Title: Peak Detection
### Aliases: getPeaks
### Keywords: nonparametric

### ** Examples

example(renorm)
peakfile <- paste(tempdir(),"testpeakinfo.csv", sep="/")
getPeaks(rtM, peakfile)



