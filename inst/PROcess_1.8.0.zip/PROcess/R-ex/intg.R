### Name: intg
### Title: Integration
### Aliases: intg
### Keywords: math

### ** Examples

x <- seq(0, 1,length=100)
y <- x^2
intg(y, x)



