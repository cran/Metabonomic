### Name: koplsDummy
### Title: Convertion of integer vector to dummy matrix
### Aliases: koplsDummy
### Keywords: multivariate

### ** Examples




