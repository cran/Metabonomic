### Name: aveSpec
### Title: Compute mean spectrum of a set of spectra
### Aliases: aveSpec
### Keywords: arith

### ** Examples

testfs <- dir(system.file("Test", package = "PROcess"),
        full.names=TRUE)
testAve <- aveSpec(testfs)



