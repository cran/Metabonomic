### Name: koplsCenterKTrTr
### Title: Centering function for the training kernel
### Aliases: koplsCenterKTrTr
### Keywords: multivariate

### ** Examples


## Load data set
data(koplsExample)

## Define kernel function parameter
sigma<-25

## Construct kernel
Ktr<-koplsKernel(Xtr,NULL,'g',sigma)

## Center kernel
Ktr_centered<-koplsCenterKTrTr(Ktr)




