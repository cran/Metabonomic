### Name: rmBaseline
### Title: Batch Baseline Subtraction.
### Aliases: rmBaseline
### Keywords: nonparametric

### ** Examples

testdir <- system.file("Test", package = "PROcess")
testM <- rmBaseline(testdir)



