### Name: koplsCenterKTeTr
### Title: Centering function for the hybrid test/training kernel
### Aliases: koplsCenterKTeTr
### Keywords: multivariate

### ** Examples


## Load data set
data(koplsExample)

## Define kernel function parameter
sigma<-25

## Construct kernels
Ktr<-koplsKernel(Xtr,NULL,'g',sigma)
KteTr<-koplsKernel(Xte,Xtr,'g',sigma)

## Center kernel
KteTr_centered<-koplsCenterKTeTr(KteTr, Ktr)




