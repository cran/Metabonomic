### Name: quality
### Title: Quality Check on a Set of Spectra
### Aliases: quality
### Keywords: math

### ** Examples

example(getPeaks)
qualRes <- quality(testM, peakfile, cutoff=1500)



