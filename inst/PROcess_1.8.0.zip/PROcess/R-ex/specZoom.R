### Name: specZoom
### Title: Plotting a Spectrum with Peaks
### Aliases: specZoom
### Keywords: hplot

### ** Examples

example(isPeak)
specZoom(pkobj, xlim=c(5000, 10000))



