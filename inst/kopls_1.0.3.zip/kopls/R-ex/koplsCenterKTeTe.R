### Name: koplsCenterKTeTe
### Title: Centering function for the test kernel
### Aliases: koplsCenterKTeTe
### Keywords: multivariate

### ** Examples


## Load data set
data(koplsExample)

## Define kernel function parameter
sigma<-25

## Construct kernels
Ktr<-koplsKernel(Xtr,NULL,'g',sigma)
KteTr<-koplsKernel(Xte,Xtr,'g',sigma)
KteTe<-koplsKernel(Xte,NULL,'g',sigma)

## Center kernel
KteTe_centered<-koplsCenterKTeTe(KteTe, KteTr, Ktr)




