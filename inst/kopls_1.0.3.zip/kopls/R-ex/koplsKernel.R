### Name: koplsKernel
### Title: Kernel construction method
### Aliases: koplsKernel
### Keywords: multivariate

### ** Examples


data(koplsExample)

## Define kernel function parameter
sigma<-25

## Construct kernels
Ktr<-koplsKernel(Xtr,NULL,'g',sigma)
KteTr<-koplsKernel(Xte,Xtr,'g',sigma)
KteTe<-koplsKernel(Xte,NULL,'g',sigma)




