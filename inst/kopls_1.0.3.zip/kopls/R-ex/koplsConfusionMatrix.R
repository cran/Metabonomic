### Name: koplsConfusionMatrix
### Title: Calculation of confusion matrix
### Aliases: koplsConfusionMatrix
### Keywords: multivariate

### ** Examples




