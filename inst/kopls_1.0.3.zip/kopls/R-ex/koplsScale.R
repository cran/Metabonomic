### Name: koplsScale
### Title: Matrix scaling function
### Aliases: koplsScale
### Keywords: multivariate

### ** Examples




