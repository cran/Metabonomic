### Name: kopls-package
### Title: Kernel-based orthogonal projections to latent structures
###   (K-OPLS)
### Aliases: kopls-package kopls
### Keywords: package multivariate

### ** Examples


  ##Run demo to get further info:
  demo(koplsDemo)




