### Name: koplsMaxClassify
### Title: Classification rule based on the maximum class belonging
### Aliases: koplsMaxClassify
### Keywords: multivariate

### ** Examples




