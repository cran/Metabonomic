### Name: koplsBasicClassify
### Title: Classification rule based on a fixed threshold
### Aliases: koplsBasicClassify
### Keywords: multivariate

### ** Examples




