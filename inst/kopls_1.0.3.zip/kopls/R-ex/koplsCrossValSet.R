### Name: koplsCrossValSet
### Title: Generate training/test observations for cross-validation
### Aliases: koplsCrossValSet
### Keywords: multivariate

### ** Examples




