### Name: koplsSensSpec
### Title: Sensitivity and specificity calculations for classification
### Aliases: koplsSensSpec
### Keywords: multivariate

### ** Examples




