### Name: renorm
### Title: Renormalize Spectra
### Aliases: renorm
### Keywords: utilities

### ** Examples

example(rmBaseline)
rtM <- renorm(testM, cutoff=1500)



