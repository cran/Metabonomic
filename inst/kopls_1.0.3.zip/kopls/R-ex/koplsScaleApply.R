### Name: koplsScaleApply
### Title: Apply matrix scaling
### Aliases: koplsScaleApply
### Keywords: multivariate

### ** Examples




