### Name: koplsPlotModelDiagnostics
### Title: Overview of model training results
### Aliases: koplsPlotModelDiagnostics
### Keywords: multivariate

### ** Examples


## Load data set
data(koplsExample)

## Define kernel function parameter
sigma<-25

## Define number of Y-orthogonal components
nox<-3

## Construct kernel
Ktr<-koplsKernel(Xtr,NULL,'g',sigma)

## Model 
model<-koplsModel(Ktr,Ytr,1,nox,'mc','mc');

## Visualize results
koplsPlotModelDiagnostics(model)
title("Model diagnostics without cross-validation")




